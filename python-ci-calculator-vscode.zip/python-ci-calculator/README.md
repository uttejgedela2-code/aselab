# Python CI Calculator

A simple Python calculator project demonstrating Continuous Integration with GitHub Actions.

## Features
- Addition, subtraction, multiplication, and division
- Five unit tests using pytest
- Code linting using flake8
- GitHub Actions workflow runs on every push and pull request

## Run locally

Install dependencies:

```bash
python -m pip install -r requirements.txt
```

Run linting:

```bash
python -m flake8 calculator.py test_calculator.py
```

Run unit tests:

```bash
python -m pytest -v
```

## GitHub Actions
The workflow is defined in `.github/workflows/ci.yml`.
